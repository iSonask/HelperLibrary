//
//  SegueIdentifier.swift
//  CoordinatorPatternDemo
//
//  Created by CodeCat15 on 1/11/22.
//

import Foundation

struct StoryBoardIdentifier {
    static let Home = "HomeVC"
}
