//
//  LoginView.swift
//  MvvmDemoApp
//
//  Created by CodeCat15 on 3/15/20.
//  Copyright © 2020 Codecat15. All rights reserved.
//

import UIKit

class LoginView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
