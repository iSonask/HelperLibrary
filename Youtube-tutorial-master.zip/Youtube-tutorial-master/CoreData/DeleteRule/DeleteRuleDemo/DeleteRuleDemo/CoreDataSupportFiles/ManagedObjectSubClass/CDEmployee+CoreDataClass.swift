//
//  CDEmployee+CoreDataClass.swift
//  DeleteRuleDemo
//
//  Created by CodeCat15 on 8/28/20.
//  Copyright © 2020 CodeCat15. All rights reserved.
//
//

import Foundation
import CoreData

@objc(CDEmployee)
public class CDEmployee: NSManagedObject {

}
