//
//  RegisterEmployeeManager.swift
//  CDcrudOperations
//
//  Created by CodeCat15 on 6/19/20.
//  Copyright © 2020 CodeCat15. All rights reserved.
//

import Foundation
import CoreData

struct EmployeeManager
{
    func createEmployee(employee: Employee) {
        // create employee code here
    }

    func fetchEmployee() -> [Employee]? {
        // fetch employee code here
        return nil
    }

    func updateEmployee(employee: Employee) -> Bool {
        // update employee code here
        return false
    }

    func deleteEmployee(id: UUID) -> Bool {
        // delete employee code here
        return false
    }
}
