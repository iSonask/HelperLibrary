//
//  CDEmployee+CoreDataClass.swift
//  CDcrudOperations
//
//  Created by CodeCat15 on 6/19/20.
//  Copyright © 2020 CodeCat15. All rights reserved.
//
//

import Foundation
import CoreData

@objc(CDEmployee)
public class CDEmployee: NSManagedObject {

}
