//
//  AnimalViewCell.swift
//  CoreDataSyncPart1
//
//  Created by CodeCat15 on 8/21/21.
//

import UIKit

class AnimalViewCell: UITableViewCell {

    @IBOutlet weak var lblAnimalName: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
