//
//  CommonConstants.swift
//  CoreDataSyncPart1
//
//  Created by CodeCat15 on 8/14/21.
//

import Foundation

struct ApiResource {
    static let animalResource : URL = URL(string: "https://api-dev-scus-demo.azurewebsites.net/api/Animal/GetAnimals")!
}
