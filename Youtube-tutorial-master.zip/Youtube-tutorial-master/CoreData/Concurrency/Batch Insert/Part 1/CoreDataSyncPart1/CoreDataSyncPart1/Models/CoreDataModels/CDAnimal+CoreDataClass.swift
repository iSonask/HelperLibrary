//
//  CDAnimal+CoreDataClass.swift
//  CoreDataSyncPart1
//
//  Created by CodeCat15 on 8/14/21.
//
//

import Foundation
import CoreData

@objc(CDAnimal)
public class CDAnimal: NSManagedObject {

}
