//
//  SegueIdentifier.swift
//  CDRelationships
//
//  Created by CodeCat15 on 7/10/20.
//  Copyright © 2020 CodeCat15. All rights reserved.
//

import Foundation

struct SegueIdentifier
{
    static let navigateToDetailView = "navigateToDetailView"
    static let showPassportDetails = "showPassportDetails"
}
