//
//  PassportListTC.swift
//  CDRelationships
//
//  Created by CodeCat15 on 7/8/20.
//  Copyright © 2020 CodeCat15. All rights reserved.
//

import UIKit

class PassportListTC: UITableViewCell {

    @IBOutlet weak var lblEmployeeName: UILabel!
    @IBOutlet weak var lblPassportId: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
