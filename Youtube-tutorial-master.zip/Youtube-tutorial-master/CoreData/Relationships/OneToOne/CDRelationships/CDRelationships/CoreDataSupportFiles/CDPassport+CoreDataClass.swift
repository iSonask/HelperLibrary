//
//  CDPassport+CoreDataClass.swift
//  CDRelationships
//
//  Created by CodeCat15 on 7/10/20.
//  Copyright © 2020 CodeCat15. All rights reserved.
//
//

import Foundation
import CoreData

@objc(CDPassport)
public class CDPassport: NSManagedObject {

}
