//
//  CDPerson+CoreDataClass.swift
//  OTMCoreDataDemo
//
//  Created by CodeCat15 on 7/18/20.
//  Copyright © 2020 CodeCat15. All rights reserved.
//
//

import Foundation
import CoreData

@objc(CDPerson)
public class CDPerson: NSManagedObject {

}
