//
//  Common.swift
//  MyPlacesApp
//
//  Created by CodeCat15 on 10/31/20.
//

import Foundation

struct SegueIdentifier{
    static let placesMapView = "showMapView"
}

struct API {
    static let key: String = "PLEASE_ENTER_YOUR_GOOGLE_PLACES_API_TOKEN_HERE"
}
