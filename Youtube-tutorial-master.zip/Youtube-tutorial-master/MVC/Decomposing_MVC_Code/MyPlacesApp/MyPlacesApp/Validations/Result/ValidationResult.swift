//
//  ValidationResult.swift
//  MyPlacesApp
//
//  Created by CodeCat15 on 11/13/20.
//

import Foundation

struct ValidationResult{
    let success: Bool
    let errorMessage: String?
}
