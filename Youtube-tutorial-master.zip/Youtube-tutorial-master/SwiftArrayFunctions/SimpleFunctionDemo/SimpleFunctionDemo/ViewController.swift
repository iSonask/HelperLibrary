//
//  ViewController.swift
//  SimpleFunctionDemo
//
//  Created by CodeCat15 on 11/24/22.
//

import UIKit

/**
 2. drop(while) (remove unless a particular condition is false and then return the pending elements 1,2,6,1)
 3. dropFirst (drop first two elements)
 5. contains
 6. reduce
 */

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

