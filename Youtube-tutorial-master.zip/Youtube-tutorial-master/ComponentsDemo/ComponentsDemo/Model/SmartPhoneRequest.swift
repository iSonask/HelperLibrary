//
//  SmartPhoneRequest.swift
//  MyProject
//
//  Created by CodeCat15 on 5/28/20.
//  Copyright © 2020 CodeCat15. All rights reserved.
//

import Foundation

struct SmartPhoneRequest : Encodable
{
    let color, manufacturer: String?
}
