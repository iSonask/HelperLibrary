//
//  HomeChildParameter.swift
//  CoordinatorPatternDemo
//
//  Created by CodeCat15 on 2/5/22.
//

import Foundation

struct HomeChildParameter : Decodable {
    let userName : String
}
