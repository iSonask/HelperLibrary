//
//  Solution.swift
//  Demo
//
//  Created by Codecat15 on 7/20/22.
//

import Foundation


class Car {
    var name: String
    init(withName _name: String) {
        name = _name
    }
}
