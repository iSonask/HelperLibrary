//
//  LazyLoadingDemoApp.swift
//  LazyLoadingDemo
//
//  Created by CodeCat15 on 7/3/21.
//

import SwiftUI

@main
struct LazyLoadingDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
