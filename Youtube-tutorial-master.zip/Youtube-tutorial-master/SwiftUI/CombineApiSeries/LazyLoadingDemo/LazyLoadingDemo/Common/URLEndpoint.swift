//
//  URLEndpoint.swift
//  LazyLoadingDemo
//
//  Created by CodeCat15 on 7/4/21.
//

import Foundation

struct URLEndpoint {
    static let getAnimal : URL = URL(string: "https://api-dev-scus-demo.azurewebsites.net/api/Animal/GetAnimals")!
}
