//
//  ValidationResult.swift
//  MvvmDemoApp
//
//  Created by CodeCat15 on 3/14/20.
//  Copyright © 2020 Codecat15. All rights reserved.
//

import Foundation

struct ValidationResult
{
    let success: Bool
    let error : String?
}
