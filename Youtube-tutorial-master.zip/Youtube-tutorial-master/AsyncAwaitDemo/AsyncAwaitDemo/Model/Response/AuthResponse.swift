//
//  AuthResponse.swift
//  AsyncAwaitDemo
//
//  Created by CodeCat15 on 11/15/21.
//

import Foundation

struct AuthResponse : Decodable {
    let token: String
}
