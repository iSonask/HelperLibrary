//
//  PayrollBody.swift
//  AsyncAwaitDemo
//
//  Created by CodeCat15 on 12/2/21.
//

import Foundation

struct PayrollBody : Encodable {
    let token: String
}
