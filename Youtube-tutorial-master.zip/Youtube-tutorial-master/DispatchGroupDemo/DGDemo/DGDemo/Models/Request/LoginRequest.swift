//
//  LoginRequest.swift
//  DGDemo
//
//  Created by CodeCat15 on 2/12/21.
//

import Foundation

struct LoginRequest : Encodable {
    let userEmail, userPassword : String
}
