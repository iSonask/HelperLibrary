//
//  DepartmentRequest.swift
//  DGDemo
//
//  Created by CodeCat15 on 2/12/21.
//

import Foundation

struct DepartmentRequest {
    let userId : Int
    let department : String
}
